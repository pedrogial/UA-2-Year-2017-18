15419933

# Pr�cticas de Programaci�n 3: Juego de la vida de Conway
**Alumno/a:** Pedro Gim�nez Aldeguer

**Grupo de pr�cticas:** 7
