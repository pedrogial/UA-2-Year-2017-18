package entradasalida;

import entradasalida.excepciones.ExcepcionGeneracion;
import modelo.Coordenada;
import modelo.Regla;
import modelo.Tablero;
import modelo.d1.Coordenada1D;
import modelo.d1.Regla30;
import modelo.d1.Tablero1D;
import modelo.d2.Coordenada2D;
import modelo.d2.ReglaConway;
import modelo.d2.Tablero2D;
import modelo.d2.TableroCeldasCuadradas;
import modelo.excepciones.ExcepcionArgumentosIncorrectos;
import modelo.excepciones.ExcepcionCoordenadaIncorrecta;
import modelo.excepciones.ExcepcionEjecucion;

/**
 * La clase Factory
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Factory{
	
	/**
	 * Instantiates a new factory.
	 */
	public Factory() {
		
	}
	
	/**
	 * Crea generador fichero.
	 *
	 * @param tablero the tablero
	 * @param extension the extension
	 * @return the i generador fichero
	 * @throws ExcepcionGeneracion the excepcion generacion
	 */
	public static IGeneradorFichero creaGeneradorFichero(Tablero tablero, String extension) throws ExcepcionGeneracion{
		IGeneradorFichero fichero = null;
		String s;
		if(tablero == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(extension == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		s = "entradasalida." + extension + ".GeneradorTablero" + tablero.getDimensiones().getClass().getSimpleName();
	
		try {
			Class instancia = Class.forName(s);
			fichero = (IGeneradorFichero) instancia.newInstance();
		}catch(ClassNotFoundException e){
			throw new ExcepcionGeneracion(s);
		}catch(InstantiationException | IllegalAccessException e) {
			throw new ExcepcionGeneracion("Error");
		}
			
		return fichero;
	}
	
	/**
	 * Crea regla.
	 *
	 * @param tablero the tablero
	 * @return the regla
	 */
	public static Regla creaRegla(Tablero tablero){
		
		if(tablero == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		if(tablero instanceof Tablero1D) {
			return new Regla30();
		}
		else {
			if(tablero instanceof Tablero2D) {
				return new ReglaConway();
			}
			else {
				throw new ExcepcionEjecucion("Error");
			}
		}
	}

	/**
	 * Crea tablero.
	 *
	 * @param dimensiones the dimensiones
	 * @return the tablero
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 */
	public static Tablero creaTablero(Coordenada dimensiones) throws ExcepcionCoordenadaIncorrecta{
		if(dimensiones == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(dimensiones instanceof Coordenada2D) {
			Coordenada2D c = (Coordenada2D) dimensiones;
			return new TableroCeldasCuadradas(c.getX(), c.getY());
		}
		else {
			if(dimensiones instanceof Coordenada1D) {
				Coordenada1D c = (Coordenada1D) dimensiones;
				return new Tablero1D(c.getX());
			}
			else {
				throw new ExcepcionEjecucion("Error");
			}
			
		}
	}
	
}
