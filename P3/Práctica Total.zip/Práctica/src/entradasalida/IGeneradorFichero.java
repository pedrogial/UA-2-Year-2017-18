package entradasalida;

import java.io.File;

import entradasalida.excepciones.ExcepcionGeneracion;
import modelo.Juego;

/**
 * La interfaz IGeneradorFichero
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public interface IGeneradorFichero {
	
	/**
	 * Genera fichero.
	 *
	 * @param file the file
	 * @param juego the juego
	 * @param iteraciones the iteraciones
	 * @throws ExcepcionGeneracion the excepcion generacion
	 */
	public abstract void generaFichero(File file, Juego juego, int iteraciones) throws ExcepcionGeneracion;

}
