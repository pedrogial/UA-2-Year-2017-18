package entradasalida;

import entradasalida.excepciones.ExcepcionLectura;
import modelo.Tablero;

/**
 * La interfaz IParserTablero
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public interface IParserTablero {
	
	/**
	 * Lee tablero.
	 *
	 * @param nombre the nombre
	 * @return the tablero
	 * @throws ExcepcionLectura the excepcion lectura
	 */
	public abstract Tablero leeTablero(String nombre) throws ExcepcionLectura;
}
