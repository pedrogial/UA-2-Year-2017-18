package entradasalida;

import entradasalida.excepciones.ExcepcionLectura;
import entradasalida.txt.ParserTablero1D;
import entradasalida.txt.ParserTablero2D;
import modelo.Tablero;
import modelo.excepciones.ExcepcionArgumentosIncorrectos;

/**
 * La clase ParserTableros
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ParserTableros {
	
	/**
	 * Instantiates a new parser tableros.
	 */
	public ParserTableros() {
		
	}
	
	/**
	 * Lee tablero.
	 *
	 * @param s the s
	 * @return the tablero
	 * @throws ExcepcionLectura the excepcion lectura
	 */
	public static Tablero leeTablero(String s) throws ExcepcionLectura{
		int esta;	
		if(s == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		if(s.equals("")) {
			throw new ExcepcionLectura();
		}
		esta = s.indexOf('\n');
		
		if(esta != -1) {
			IParserTablero parser2D = new ParserTablero2D();
			return parser2D.leeTablero(s);
		}
		
		else {
			IParserTablero parser1D = new ParserTablero1D();
			return parser1D.leeTablero(s);
		}
	}
}
