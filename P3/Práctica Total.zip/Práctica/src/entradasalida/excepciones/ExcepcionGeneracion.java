package entradasalida.excepciones;

/**
 * La clase ExcepcionGeneracion
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionGeneracion extends Exception{
	
	/**
	 * Instantiates a new excepcion generacion.
	 */
	public ExcepcionGeneracion(){
		super("Error generacion");
	}
	
	/**
	 * Instantiates a new excepcion generacion.
	 *
	 * @param s the s
	 */
	public ExcepcionGeneracion(String s){
		super(s);
	}
	
	/**
	 * Instantiates a new excepcion generacion.
	 *
	 * @param t the t
	 */
	public ExcepcionGeneracion(Throwable t) {
		super (t);
	}
}
