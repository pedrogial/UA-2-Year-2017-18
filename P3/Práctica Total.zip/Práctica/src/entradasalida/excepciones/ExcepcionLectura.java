package entradasalida.excepciones;

/**
 * La clase ExcepcionLectura
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionLectura extends Exception{
	
	/**
	 * Instantiates a new excepcion lectura.
	 */
	public ExcepcionLectura() {
		super("Error lectura");
	}
	
	/**
	 * Instantiates a new excepcion lectura.
	 *
	 * @param s the s
	 */
	public ExcepcionLectura(String s) {
		super(s);
	}
	
	/**
	 * Instantiates a new excepcion lectura.
	 *
	 * @param t the t
	 */
	public ExcepcionLectura(Throwable t) {
		super(t);
	}
}
