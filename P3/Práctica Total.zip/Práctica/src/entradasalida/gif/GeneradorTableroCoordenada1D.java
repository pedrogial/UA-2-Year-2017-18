package entradasalida.gif;

import java.io.File;

import entradasalida.IGeneradorFichero;
import entradasalida.excepciones.ExcepcionGeneracion;
import gifs.ImagenGIF;
import modelo.EstadoCelda;
import modelo.Imprimible;
import modelo.Juego;
import modelo.d1.Coordenada1D;
import modelo.excepciones.ExcepcionArgumentosIncorrectos;

/**
 * La clase GeneradorGIFTablero1D
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class GeneradorTableroCoordenada1D implements IGeneradorFichero{
	
	/**
	 * Instantiates a new generador GIF tablero 1 D.
	 */
	public GeneradorTableroCoordenada1D() {
		
	}
	
	@Override
	public void generaFichero(File file, Juego juego, int iteraciones) throws ExcepcionGeneracion{
		if(file == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(juego == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(iteraciones <= 0) {
			throw new ExcepcionGeneracion("Iteraciones incorrectas");
		}
		if(juego.getTablero() instanceof Imprimible == false) {
			throw new ExcepcionGeneracion("Error");
		}
		
		Coordenada1D c1 = (Coordenada1D)juego.getTablero().getDimensiones();
		int fila = c1.getX();
		
		/*
		 *	gif = crea ImagenGIF con la anchura y altura del tablero
		 *	para y = 0 hasta iteraciones-1 hacer
		 *		para x = 0 hasta (anchura_tablero - 1) hacer
		 *      	si la celda en la posición (x) del tablero está viva entonces
		 *          	gif.pintaCuadrado(x, y)
		 *      	finsi
		 *		finpara
		 * 		juego.actualiza()
		 *	finpara
		 *	guarda gif en fichero
		 */
		try {
			ImagenGIF g1d = new ImagenGIF(fila, iteraciones);
			for(int i = 0; i <= iteraciones-1; i++) {
				for(int j = 0; j <= fila -1; j++) {
					EstadoCelda Actual = juego.getTablero().getCelda(new Coordenada1D(j));
					if( Actual == EstadoCelda.VIVA) {
						g1d.pintaCuadrado(j, i);
					}
				}
				juego.actualiza();
			}
			g1d.guardaFichero(file);
			
		}catch(Exception e) {	
		}
		
	}
}
