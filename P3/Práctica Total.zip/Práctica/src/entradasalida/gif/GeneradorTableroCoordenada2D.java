package entradasalida.gif;

import java.io.File;

import entradasalida.IGeneradorFichero;
import entradasalida.excepciones.ExcepcionGeneracion;
import gifs.ImagenGIF;
import gifs.ImagenGIFAnimado;
import modelo.EstadoCelda;
import modelo.Imprimible;
import modelo.Juego;
import modelo.d2.Coordenada2D;
import modelo.excepciones.ExcepcionArgumentosIncorrectos;

/**
 * La clase GeneradorGifAnimadoTablero2D
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class GeneradorTableroCoordenada2D implements IGeneradorFichero{
	
	/**
	 * Instantiates a new generador gif animado tablero 2 D.
	 */
	public GeneradorTableroCoordenada2D() {
		
	}
	
	@Override
	public void generaFichero(File file, Juego juego, int iteraciones) throws ExcepcionGeneracion{
		if(file == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(juego == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(iteraciones <= 0) {
			throw new ExcepcionGeneracion("Iteraciones incorrectas");
		}
		if(juego.getTablero() instanceof Imprimible == false) {
			throw new ExcepcionGeneracion("Error");
		}
		
		Coordenada2D c2 = (Coordenada2D)juego.getTablero().getDimensiones();
		int ancho = c2.getX(); 
		int alto = c2.getY();
		
		/*
		 *	gifAnimado = crea ImagenGIFAnimado usando un retardo de 100 ms
		 *	para i=0 hasta (iteraciones-1) hacer
         *		fotograma = crea ImagenGIF con la anchura y altura del tablero
         *		para x = 0 hasta (anchura_tablero - 1) hacer
         *    		para y = 0 hasta (altura_tablero - 1) hacer
         *        		si la celda en la posición (x, y) del tablero está viva entonces
         *            		fotograma.pintaCuadrado(x,y)
         *      		finsi
         *			finpara
         *		finpara
         *		añadimos el fotograma al gifAnimado usando addFotograma()
         *		evolucionamos el juego con actualiza()
         *	finpara 
         *	guardamos el fichero con el método guardaFichero() del gifAnimado
         */
		try {
			ImagenGIFAnimado  anime = new ImagenGIFAnimado(100);
			for(int it = 0; it <= iteraciones-1; it++) {
				ImagenGIF g2d = new ImagenGIF(ancho, alto);
				for(int i = 0; i <= ancho-1; i++) {
					for(int j = 0; j <= alto-1; j++) {
						EstadoCelda Actual = (juego.getTablero().getCelda(new Coordenada2D(j, i)));
						if(Actual == EstadoCelda.VIVA) {
							g2d.pintaCuadrado(j, i);
						}
					}
				}
				anime.addFotograma(g2d);
				juego.actualiza();
			}
			anime.guardaFichero(file);
		}
		catch(Exception e) {
		}
	}
}
