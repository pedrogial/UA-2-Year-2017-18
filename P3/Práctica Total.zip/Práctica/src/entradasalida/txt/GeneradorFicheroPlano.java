package entradasalida.txt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import entradasalida.IGeneradorFichero;
import entradasalida.excepciones.ExcepcionGeneracion;
import modelo.Imprimible;
import modelo.Juego;
import modelo.excepciones.ExcepcionArgumentosIncorrectos;

/**
 * La clase GeneradorFicheroPlano
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class GeneradorFicheroPlano implements IGeneradorFichero{
	
	/**
	 * Instantiates a new generador fichero plano.
	 */
	public GeneradorFicheroPlano() {
		
	}
	
	@Override
	public void generaFichero(File file, Juego juego, int iteraciones) throws ExcepcionGeneracion{
		if(file == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(juego == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(iteraciones <= 0) {
			throw new ExcepcionGeneracion("Error");
		}
		if(juego.getTablero() instanceof Imprimible == false) {
			throw new ExcepcionGeneracion("Error");
		}
		
		/*
		 *  para i=0 hasta iteraciones-1 hacer
         *		juego.actualiza()
         *		// añadir al fichero la cadena obtenida de la llamada
         *		// a generarCadena de Tablero (el cual debe implementar Imprimible)
         *	finpara
		 */
		try {		
			PrintWriter escribir = new PrintWriter(file);
			for(int i = 0; i <= iteraciones-1; i++) {
				juego.actualiza();
				escribir.print(((Imprimible)juego.getTablero()).generaCadena());
			}
			escribir.close();
		}catch(FileNotFoundException e) {
			throw new ExcepcionGeneracion("Error Fichero");
		}
	}
}
