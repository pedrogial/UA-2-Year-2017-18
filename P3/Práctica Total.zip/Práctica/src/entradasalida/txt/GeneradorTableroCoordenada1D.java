package entradasalida.txt;

public class GeneradorTableroCoordenada1D extends GeneradorFicheroPlano{

}
