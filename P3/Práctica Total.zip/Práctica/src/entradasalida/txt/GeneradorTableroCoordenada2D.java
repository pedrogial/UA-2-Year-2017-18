package entradasalida.txt;

public class GeneradorTableroCoordenada2D extends GeneradorFicheroPlano{

}
