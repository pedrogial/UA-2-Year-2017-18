package entradasalida.txt;

import entradasalida.IParserTablero;
import entradasalida.excepciones.ExcepcionLectura;
import modelo.EstadoCelda;
import modelo.Tablero;
import modelo.d1.Coordenada1D;
import modelo.d1.Tablero1D;
import modelo.excepciones.*;

/**
 * La clase ParserTablero1D
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ParserTablero1D implements IParserTablero{
	
	/**
	 * Instantiates a new parser tablero 1 D.
	 */
	public ParserTablero1D() {
		
	}
	
	@Override
	public Tablero leeTablero(String s) throws ExcepcionLectura{
		Tablero t = null;
	
		if(s == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(s.equals("")) {
			throw new ExcepcionLectura("Error lectura");
		}
		else {
			for(int i = 0; i < s.length(); i++) {
				if(s.charAt(i) != ' ' && s.charAt(i) != '*'){
					throw new ExcepcionLectura("Error lectura");
				}
			}
		}
		try {
			t = new Tablero1D(s.length());
			for(int i = 0; i < s.length(); i++) {
				t.setCelda(new Coordenada1D(i), EstadoCelda.VIVA);
				if(s.charAt(i) == ' ' ){
					t.setCelda(new Coordenada1D(i), EstadoCelda.MUERTA);
				}
			}
		}catch(Exception e) {
			throw new ExcepcionEjecucion(e);
		}
		return t;
	}
}