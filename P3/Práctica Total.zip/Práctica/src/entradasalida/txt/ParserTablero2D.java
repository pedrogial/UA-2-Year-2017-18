package entradasalida.txt;

import entradasalida.IParserTablero;
import entradasalida.excepciones.ExcepcionLectura;
import modelo.EstadoCelda;
import modelo.Tablero;
import modelo.d2.Coordenada2D;
import modelo.d2.TableroCeldasCuadradas;
import modelo.excepciones.ExcepcionArgumentosIncorrectos;
import modelo.excepciones.ExcepcionEjecucion;

/**
 * La clase ParserTablero2D
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ParserTablero2D implements IParserTablero{
	
	/**
	 * Instantiates a new parser tablero 2 D.
	 */
	public ParserTablero2D(){
	}
	
	@Override
	public Tablero leeTablero(String s) throws ExcepcionLectura{
		String [] filas;
		Tablero t = null; 
		 
		if(s == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(s.equals("")) {
			throw new ExcepcionLectura("Error lectura");
		}
		
		else {	
			filas = s.split("\n");
			int longitud = filas[0].length();
			 
			for(int i = 1; i < filas.length; i++) {
				if(filas[i].length() != longitud) {
					throw new ExcepcionLectura("Error longitud");
						
				}
			}
			for(int i = 0; i < filas.length; i++) {
				for(int j = 0; j < filas[i].length(); j++) {
					if(filas[i].charAt(j) != ' ' && filas[i].charAt(j) != '*'){
						throw new ExcepcionLectura("Error lectura");
					}
				}
			}
		}
		try {
			t = new TableroCeldasCuadradas(filas[0].length(), filas.length);
			for(int i = 0; i < filas.length; i++) {
				for(int j = 0; j < filas[i].length(); j++) {
					t.setCelda(new Coordenada2D(j, i), EstadoCelda.VIVA);
					if(filas[i].charAt(j) == ' ') {
						t.setCelda(new Coordenada2D(j, i), EstadoCelda.MUERTA);
					}
				}
			}
		}catch(Exception e) {
			throw new ExcepcionEjecucion(e);
		}
		return t;
	 }
}
