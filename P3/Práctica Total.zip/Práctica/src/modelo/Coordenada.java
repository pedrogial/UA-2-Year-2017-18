package modelo;
import modelo.excepciones.*;

/**
 * La clase Coordenada abstracta: Sistema de coordenadas cartesianas con valores x e y o solo x.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public abstract class Coordenada {
	
	/**
	 * Constructor vacio de Coordenada.
	 */
	public Coordenada() {
	}
	
	/**
	 * Método abstracto de Coordenada que se encarga de sumar dos coordenadas.
	 *
	 * @param otra  Otra coordenada como parametro.
	 * @return Coordenada total.
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public abstract Coordenada suma(Coordenada otra) throws ExcepcionCoordenadaIncorrecta, ExcepcionArgumentosIncorrectos;
}
