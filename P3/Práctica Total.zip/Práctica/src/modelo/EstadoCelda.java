package modelo;

/**
 * La clase EstadoCelda: Tipo enumerado con los valores MUERTA y VIVA.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */

public enum EstadoCelda {
	
		/** Celda viva. */
		VIVA,
		
		/** Celda muerta. */
		MUERTA;
	
}
