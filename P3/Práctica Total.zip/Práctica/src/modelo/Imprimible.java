package modelo;

/**
 * La interfaz imprimible: los objetos tablero que se van a imprimir y que generen una cadena
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public interface Imprimible {
	
	/**
	 * Genera cadena.
	 *
	 * @return the string
	 */
	public abstract String generaCadena();
}
