package modelo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import modelo.excepciones.*;

/**
 * La clase Juego: Coordina el resto de clases, capaz de evolucionar las celdas.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Juego<TipoCoordenada extends Coordenada>{

	/** The tablero. */
	private Tablero<TipoCoordenada> tablero;
	
	/** The regla. */
	private Regla<TipoCoordenada> regla;
	
	/** The patrones usados. */
	private ArrayList<Patron<TipoCoordenada>> patronesUsados;
	
	/**
	 * Constructor: Inicializa los campos y guarda los parámetros recibidos.
	 * Instantiates a new juego.
	 *
	 * @param tablero El parámetro tablero
	 * @param regla El parámetro regla
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public Juego(Tablero<TipoCoordenada> tablero, Regla<TipoCoordenada> regla) throws ExcepcionArgumentosIncorrectos{
		if(tablero == null || regla == null){
			throw new ExcepcionArgumentosIncorrectos();
		}
		else {
			this.tablero = tablero;
			this.regla = regla;
			patronesUsados = new ArrayList<Patron<TipoCoordenada>>();
		}
	}

	/**
	 * 
	 * Carga el patron en el tablero y lo guarda entre los patronesUsados.
	 * Si el patron no cabe no se guarda y emite un error.
	 *
	 * @param p the p
	 * @param posicionInicial the posicion inicial
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionEjecucion the excepcion ejecucion
	 */
	public void cargaPatron(Patron<TipoCoordenada> p , TipoCoordenada posicionInicial) throws ExcepcionPosicionFueraTablero, ExcepcionArgumentosIncorrectos, ExcepcionEjecucion{
		tablero.cargaPatron(p, posicionInicial);
		patronesUsados.add(p);	
	}

	/**
	 * Evoluciona todas las casillas del tablero simultáneamente usando una de las reglas.
	 *
	 * @throws ExcepcionEjecucion the excepcion ejecucion
	 */
	public void actualiza() throws ExcepcionEjecucion{
		Collection<TipoCoordenada> celdas= tablero.getPosiciones();
		HashMap<TipoCoordenada, EstadoCelda> temporal = new HashMap<TipoCoordenada, EstadoCelda>();
		EstadoCelda nuevo;
		
		try {
			for(TipoCoordenada cero : celdas) {
				nuevo = regla.calculaSiguienteEstadoCelda(tablero, cero);
				temporal.put(cero, nuevo);
			}
			
			//Se necesita guardar temporalmente
			celdas = temporal.keySet();
			for(TipoCoordenada cero : celdas) {
				tablero.setCelda(cero, temporal.get(cero));
			}
		}catch(ExcepcionPosicionFueraTablero e) {
			throw new ExcepcionEjecucion(e);
		}
	}

	/**
	 * Devuelve el tablero
	 *
	 * @return tablero
	 */
	public Tablero<TipoCoordenada> getTablero() {
		return tablero;
	}

	/**
	 * Devuelve los patrones Usados
	 *
	 * @return patronesUsados(Contenedor ArrayList)
	 */
	public ArrayList<Patron<TipoCoordenada>>getPatrones(){
		return patronesUsados;
	}
}
