package modelo;

import java.util.Collection;

import modelo.excepciones.*;

/**
 * La clase Patron: Representa un conjunto de celdas vivas para 
 * luego meterlos en el tablero.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Patron<TipoCoordenada extends Coordenada>{
	
	/** Nombre del patron */
	private String nombre;
	
	/** El tablero específico */
	private Tablero<TipoCoordenada> tablero;

	/**
	 * Constructor: guarda los parámetros enviados en los campos correspondientes
	 * 
	 * Instantiates a new patron.
	 *
	 * @param nombre 
	 * @param tablero
	 *
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public Patron(String nombre, Tablero<TipoCoordenada> tablero) throws ExcepcionArgumentosIncorrectos{
		if(tablero == null || nombre == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		else {
			this.nombre = nombre;
			this.tablero = tablero;
		}
	}
	
	/** 
	 * Devuelve el nombre del patron
	 *
	 * @return nombre
	 */
	public String getNombre() {
		return nombre;
	}
	

	/**
	 * Devuelve el estado de la coordenada enviada.
	 * @param coordenada
	 * @return estado (VIVA o MUERTA)
	 * 
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 */
	public EstadoCelda getCelda(TipoCoordenada coordenada) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero{
		EstadoCelda estado = tablero.getCelda(coordenada);
		return estado;
	}
	

	/**
	 * Devuelve las posiciones del tablero.
	 *
	 * @return coordenada
	 */
	public Collection<TipoCoordenada> getPosiciones() {
		Collection<TipoCoordenada> coordenada = null;
		coordenada = tablero.getPosiciones();
		return coordenada;

	}

	@Override
	public String toString() {
		String s = nombre + "\n";
		s = s + tablero.toString();
		return s;
	}
}