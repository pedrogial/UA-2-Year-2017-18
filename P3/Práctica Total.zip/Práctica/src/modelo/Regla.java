package modelo;

import modelo.excepciones.*;

/**
 * Clase Regla abstracta: Representa una regla evolutiva del tablero.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public abstract class Regla<TipoCoordenada extends Coordenada> {
	
	/**
	 * Constructor vacio.
	 */
	public Regla() {	
	}
	
	/**
	 * Metodo abstracto que calcula el siguiente estado de celda.
	 *
	 * @param t the t
	 * @param posicion the posicion
	 * @return the estado celda
	 * 
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 */
	public abstract EstadoCelda calculaSiguienteEstadoCelda(Tablero<TipoCoordenada> t, TipoCoordenada posicion) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero;
}
