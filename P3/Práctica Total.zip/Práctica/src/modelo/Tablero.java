package modelo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import modelo.excepciones.*;


/**
 * La clase Tablero abstracta: Matriz de celdas usadas en el juego de la vida.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public abstract class Tablero<TipoCoordenada extends Coordenada> {
	
	/** The dimensiones. */
	protected TipoCoordenada dimensiones;
	
	/** The celdas. */
	protected HashMap<TipoCoordenada, EstadoCelda> celdas;
	
	/**
	 * Metodo abstracto que devuelve un vector de posiciones dependiendo de que dimensiones se trate.
	 *
	 * @param posicion the posicion
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 */
	public abstract ArrayList<TipoCoordenada> getPosicionesVecinasCCW(TipoCoordenada posicion) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero;
	
	@Override
	public abstract String toString();
	
	
	/**
	 * Constructor: crea un objeto de clase Tablero.
	 * Instantiates a new tablero.
	 *
	 * @param dimensiones Tamaño del tablero inicial.
	 *
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public Tablero(TipoCoordenada dimensiones) throws ExcepcionArgumentosIncorrectos{
		if(dimensiones == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		this.dimensiones = dimensiones;
	}	

	/**
	 *Devuelve las dimensiones.
	 *
	 * @return dimensiones
	 */
	public TipoCoordenada getDimensiones() {
		return dimensiones; 
	}

	/**
	 * Devuelve las posiciones del tablero.
	 *
	 * @return posiciones
	 */
	public Collection<TipoCoordenada>getPosiciones() {
		return celdas.keySet();
	}
	
	
	/**
	 * Devuelve true si la posicion enviada como parámetro se encuentra en las celdas
	 * del HashMap.
	 *
	 * @param posicion Posicion enviada
	 * @return true Si se encuentra
	 */
	public boolean contiene(TipoCoordenada posicion) {
		if(posicion == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		return celdas.containsKey(posicion);
	}
	
	/**
	 * Devuelve el estado de celda de la posicion enviada
	 *
	 * @param posicion Posicion enviada
	 * @return MUERTA, VIVA o null si es erronea.
	 *
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 */
	public EstadoCelda getCelda(TipoCoordenada posicion) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero{
		EstadoCelda estado = null;
		
		if(posicion == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		if(!contiene(posicion)) {
			throw new ExcepcionPosicionFueraTablero(dimensiones, posicion);
		}
		estado = celdas.get(posicion);
		return estado;
	}

	/**
	 * Sobreescribe la posicion y su estado, si dicha posicion ya se encontraba en
	 * el HashMap y si la posicion no se encuentra emitir error.
	 *
	 * @param posicion la posicion
	 * @param e el estado
	 *
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 */
	public void setCelda(TipoCoordenada posicion, EstadoCelda e) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero{
		if(posicion == null || e == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if (contiene(posicion)) {
			celdas.put(posicion, e);
		}
		else {
			throw new ExcepcionPosicionFueraTablero(dimensiones, posicion);
		}
	}


	/**
	 * Dado un patrón, copiará los estados de las celdas de éste en el 
	 * tablero a partir de la TipoCoordenada especificada en el parámetro. 
	 *
	 * @param patron Patron pasado como parámetro
	 * @param coordenadaInicial TipoCoordenada especificada
	 * @throws ExcepcionEjecucion the excepcion ejecucion
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public void cargaPatron(Patron<TipoCoordenada> patron, TipoCoordenada coordenadaInicial) throws ExcepcionEjecucion, ExcepcionPosicionFueraTablero, ExcepcionArgumentosIncorrectos{
		Collection<TipoCoordenada> posicion;
		TipoCoordenada xy = null;
		EstadoCelda estado;
		
		if(patron == null || coordenadaInicial == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		if(!contiene(coordenadaInicial)) {
			throw new ExcepcionPosicionFueraTablero(dimensiones, coordenadaInicial);
		}
		posicion = patron.getPosiciones();
		if(posicion != null){
			for(TipoCoordenada cero : posicion) {
				try {
					xy = (TipoCoordenada)cero.suma(coordenadaInicial);
					
				}catch(ExcepcionCoordenadaIncorrecta e) {
					throw new ExcepcionEjecucion(e);
				}
				if(!celdas.containsKey(xy)) {		
					throw new ExcepcionPosicionFueraTablero(dimensiones, xy);
				}	
			}
			posicion = patron.getPosiciones();
			for(TipoCoordenada cero : posicion) {
				try {
					xy = (TipoCoordenada)cero.suma(coordenadaInicial);
					
				}catch(ExcepcionCoordenadaIncorrecta e) {
						throw new ExcepcionEjecucion(e);
				}
				try {
					estado = patron.getCelda(cero);
					celdas.put(xy, estado);
					
				}catch(ExcepcionPosicionFueraTablero e) {
					throw new ExcepcionEjecucion(e);
				}
			}
		}
	}
}
