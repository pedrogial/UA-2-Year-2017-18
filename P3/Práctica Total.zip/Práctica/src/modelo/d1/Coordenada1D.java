package modelo.d1;

import modelo.Coordenada;
import modelo.excepciones.*;

/**
 * Clase Coordenada1D heredada de Coordenada: Sistema de coordenadas unidimensional.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Coordenada1D extends Coordenada{

	/** The x. */
	private int x;

	/**
	 * Constructor: crea un objeto de clase coordenada1D a partir de un parametro.
	 * 
	 * Instantiates a new coordenada.
	 *
	 * @param x the x
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 */
	public Coordenada1D(int x) throws ExcepcionCoordenadaIncorrecta{
		if(x < 0) {
			throw new ExcepcionCoordenada1DIncorrecta(x);
		}
		else {
			this.x = x;
		}
	}

	/**
	 * Constructor: crea un objeto de clase coordenada1D a partir de otro objeto de clase 
	 * coordenada pasado como parámetro.
	 * 
	 * Instantiates a new coordenada.
	 *
	 * @param otra Objeto de clase coordenada utilizada para crear el nuevo objeto.
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public Coordenada1D(Coordenada1D otra) throws ExcepcionArgumentosIncorrectos{	
		if(otra == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		else {
			this.x = otra.x;
		}
	}
	
	@Override
	public int hashCode() {
		final int numero = 31;
		int valor = 1;
		valor = numero * numero + x;
		return valor;
	}
		
	@Override
	public String toString(){
		return "("+ x + ")";
	}

	@Override
	public boolean equals(Object otro) {
			
		if(otro == this) {
			return true;
		}
		if (otro instanceof Coordenada1D) {
			Coordenada1D other = (Coordenada1D) otro;
			return (x == other.x);
		}
		return false;
	}
		
	/**
	 * Devuelve el valor x.
	 *
	 * @return x
	 */
	public int getX() {
		return x;
	}

	
	@Override
	public Coordenada1D suma(Coordenada otra) throws ExcepcionCoordenadaIncorrecta, ExcepcionArgumentosIncorrectos{
		if(otra == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		Coordenada1D suma = null;
		suma = new Coordenada1D(x + ((Coordenada1D)otra).x);
		return suma;
	}


}