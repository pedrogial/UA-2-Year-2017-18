package modelo.d1;

import modelo.excepciones.ExcepcionCoordenadaIncorrecta;

/**
 * La clase ExcepcionCoordenada1DIncorrecta
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionCoordenada1DIncorrecta extends ExcepcionCoordenadaIncorrecta{
	
	/** The x. */
	private int x;
	
	/**
	 * Instantiates a new excepcion coordenada 1 D incorrecta.
	 *
	 * @param x the x
	 */
	public ExcepcionCoordenada1DIncorrecta (int x) {
		this.x = x;
	}
	
	@Override
	public String getMessage() {
		return "Error " + x;
	}
	
	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public int getX() {
		return x;
	}
}
