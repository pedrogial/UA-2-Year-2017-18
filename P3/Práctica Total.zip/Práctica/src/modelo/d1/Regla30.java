package modelo.d1;

import java.util.ArrayList;


import modelo.EstadoCelda;
import modelo.Regla;
import modelo.Tablero;
import modelo.excepciones.*;

/**
 * Clase Regla30 heredada de Regla: Representa una regla evolutiva del tablero unidimensional.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Regla30 extends Regla<Coordenada1D> {

	/**
	 * Calcula el siguiente estado celda con unas reglas,
	 * ABC tres casillas contiguas, B será el nuevo estado para calcular:
	 * 
	 * 1 es celda viva y 0 es celda muerta. 
	 * Celda muerta cuando siga el esquema 111, 110, 101, 000 
	 * y Las celdas de los extremos, que sólo tienen una vecina.
	 * Celda viva todo lo demás.
	 * 
	 * @param tablero El tablero donde se hará el cálculo
	 * @param posicion la posicion inicial
	 * @return estado El estado nuevo calculado.
	 * 
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 */
	public EstadoCelda calculaSiguienteEstadoCelda(Tablero<Coordenada1D> tablero, Coordenada1D posicion) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero {
		ArrayList<Coordenada1D> vecinas = null;
		vecinas = tablero.getPosicionesVecinasCCW(posicion);
		EstadoCelda muerto = EstadoCelda.MUERTA;
		EstadoCelda vivo = EstadoCelda.VIVA;
		EstadoCelda nuevo = EstadoCelda.MUERTA;
		
		if(tablero == null || posicion == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		if(!((Tablero1D)tablero).contiene(posicion)) {
			throw new ExcepcionPosicionFueraTablero(tablero.getDimensiones(), posicion);
		}
		
		if(vecinas.size() != 1) {
			EstadoCelda A = ((Tablero1D)tablero).getCelda(vecinas.get(0));
			EstadoCelda B = ((Tablero1D)tablero).getCelda(posicion); 
			EstadoCelda C = ((Tablero1D)tablero).getCelda(vecinas.get(1));
			
			if(A == vivo && B == vivo  && C == vivo ) {
				nuevo = muerto;
			}
			else {
				if(A == vivo && B == vivo  && C == muerto ) {
					nuevo = muerto;
				}
				else {
					if(A == vivo && B == muerto && C == vivo ) {
						nuevo = muerto;
					}
					else {
						if(A == muerto && B == muerto  && C == muerto ) {
							nuevo = muerto;
						}
						else {
							nuevo = vivo;
						}
					}
				}	
			}
		}
		return nuevo;
	}
}