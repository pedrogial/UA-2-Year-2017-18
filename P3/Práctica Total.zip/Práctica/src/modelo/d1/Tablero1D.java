package modelo.d1;
import java.util.*;

import modelo.EstadoCelda;
import modelo.Imprimible;
import modelo.Tablero;
import modelo.excepciones.*;


/**
 * Clase Tablero1D heredada de Tablero: Matriz de celdas usadas en el juego de la vida, para la dimension 1D.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Tablero1D extends Tablero<Coordenada1D> implements Imprimible{
	
	@Override
	public String generaCadena() {
		return toString();
	}
	
	/**
	 * Constructor: crea un objeto de clase Tablero 1D insertando en cada celda el 
	 * estado MUERTA y guarda las posiciones de la dimension 1D en el HasMap celdas.
	 * 
	 * Instantiates a new tablero 1D.
	 *
	 * @param x the x
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 */
	public Tablero1D(int x) throws ExcepcionArgumentosIncorrectos, ExcepcionCoordenadaIncorrecta{
		super(new Coordenada1D(x));
		
		int i;
		celdas = new HashMap<Coordenada1D, EstadoCelda>();
		for(i = 0; i < x; i++) {
			try {
				celdas.put(new Coordenada1D(i), EstadoCelda.MUERTA);
			}
			catch(ExcepcionCoordenadaIncorrecta e) {
				throw new ExcepcionEjecucion(e);
			}
		}
	}
	
	/**
	 * Devuelve un vector de posiciones
	 * La celdas vecina de la posición 'x' son las posiciones (x-1) y (x+1)
	 * Hay que controlar que no nos salimos del tablero.
	 *
	 * @param posicion the posicion
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 * @throws ExcepcionEjecucion the excepcion ejecucion
	 */
	public ArrayList<Coordenada1D> getPosicionesVecinasCCW(Coordenada1D posicion) throws ExcepcionPosicionFueraTablero, ExcepcionArgumentosIncorrectos, ExcepcionEjecucion{
		ArrayList<Coordenada1D> radiopatio = null;
		radiopatio = new ArrayList<Coordenada1D>();
		int x;
		
		if(posicion == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		if(!contiene(posicion)) {
			throw new ExcepcionPosicionFueraTablero(dimensiones, posicion);
		}
		
		x = ((Coordenada1D)posicion).getX();
		try {
			if((x - 1) >= 0) {
				radiopatio.add(new Coordenada1D(x - 1));
			}
			if((x + 1) < (dimensiones).getX()) {
				radiopatio.add(new Coordenada1D(x + 1));
			}
		}
		catch(ExcepcionCoordenadaIncorrecta e) {
			throw new ExcepcionEjecucion(e);
		}
		return radiopatio;
	}
	
	@Override
	public String toString() {
		String s = "";
		int x;
		x = (dimensiones).getX();
		try {
			s = s + "|";
			for(int j = 0; j < x; j++) {
				if(celdas.get(new Coordenada1D(j)) == EstadoCelda.VIVA) {
					s = s + "*";
				}
				else {
					s = s + " ";
				}
			}
			s = s + "|" + "\n";
		}catch(ExcepcionCoordenadaIncorrecta e) { 
			throw new ExcepcionEjecucion(e);
		}
		return s;
	}
}