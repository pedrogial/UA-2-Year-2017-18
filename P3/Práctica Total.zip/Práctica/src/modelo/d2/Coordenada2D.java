package modelo.d2;

import modelo.Coordenada;
import modelo.excepciones.*;

/**
 * Clase Coordenada2D heredada de Coordenada: Sistema de coordenadas cartesianas con valores x e y.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class Coordenada2D extends Coordenada{
	
	/** The x. */
	private int x;

	/** The y. */
	private int y;
	

	/**
	 * Constructor: crea un objeto de clase coordenada2D a partir de dos parámetros.
	 * 
	 * Instantiates a new coordenada.
	 *
	 * @param x the x
	 * @param y the y
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 */
	public Coordenada2D(int x, int y) throws ExcepcionCoordenadaIncorrecta{
		if(x < 0 || y < 0) {
			throw new ExcepcionCoordenada2DIncorrecta(x, y);
		}
		else {
			this.x = x;
			this.y = y;
		}
	}
	
	/**
	 * Constructor: crea un objeto de clase coordenada2D a partir de otro objeto de clase 
	 * coordenada pasado como parámetro.
	 * 
	 * Instantiates a new coordenada.
	 *
	 * @param otra Objeto de clase coordenada utilizada para crear el nuevo objeto.
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 */
	public Coordenada2D(Coordenada2D otra) throws ExcepcionArgumentosIncorrectos{
		if(otra == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		else{
			this.x = otra.x;
			this.y = otra.y;
		}
	}
	

	@Override
	public int hashCode() {
		final int numero = 31;
		int valor = 1;
		valor = numero * numero + x;
		valor = numero * numero + y;
		return valor;
	}
	
	@Override
	public String toString(){
		return "("+ x + "," + y + ")";
	}
	
	@Override
	public boolean equals(Object otro) {
		if(otro == this) {
			return true;
		}
		if (otro instanceof Coordenada2D) {
			Coordenada2D other = (Coordenada2D) otro;
			return (x == other.x && y == other.y);
		}
		return false;
	}
	
	/**
	 * Devuelve el valor x.
	 *
	 * @return x
	 */
	public int getX() {
		return x;
	}
	

	/**
	 * Devuelve el valor y.
	 *
	 * @return y
	 */
	public int getY() {
		return y;
	}
	
	@Override
	public Coordenada2D suma(Coordenada otra) throws ExcepcionCoordenadaIncorrecta, ExcepcionArgumentosIncorrectos{
		if(otra == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		Coordenada2D suma = null;
		suma = new Coordenada2D(x + ((Coordenada2D)otra).x, y + ((Coordenada2D)otra).y);
		return suma;
	}
}
