package modelo.d2;

import modelo.excepciones.ExcepcionCoordenadaIncorrecta;

/**
 * La clase ExcepcionCoordenada2DIncorrecta
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionCoordenada2DIncorrecta extends ExcepcionCoordenadaIncorrecta{
	
	/** The y. */
	private int x, y;
	
	/**
	 * Instantiates a new excepcion coordenada 2 D incorrecta.
	 *
	 * @param x the x
	 * @param y the y
	 */
	public ExcepcionCoordenada2DIncorrecta(int x, int y) {
		this.x = x;
		this.y = y;	
	}
	
	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	public int getY() {
		return y;
	}
	
	@Override
	public String getMessage() {
		return "Error" + x + ", " + y ;
	}
}
