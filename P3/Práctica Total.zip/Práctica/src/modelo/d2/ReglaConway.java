package modelo.d2;

import java.util.ArrayList;


import modelo.EstadoCelda;
import modelo.Regla;
import modelo.Tablero;
import modelo.excepciones.*;

/**
 * Clase ReglaConway heredadad de Regla: Representa una regla evolutiva del tablero 2D.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ReglaConway extends Regla<Coordenada2D>{
	
	/**
	 * Constructor vacio.
	 */
	public ReglaConway(){
	}


	@Override
	public EstadoCelda calculaSiguienteEstadoCelda(Tablero<Coordenada2D> tablero, Coordenada2D posicion) throws ExcepcionArgumentosIncorrectos, ExcepcionPosicionFueraTablero{
		
		if(tablero == null || posicion == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		ArrayList<Coordenada2D> posicionV = tablero.getPosicionesVecinasCCW(posicion);
		int celdasV =  0;
		EstadoCelda muerto = EstadoCelda.MUERTA;
		EstadoCelda vivo = EstadoCelda.VIVA;

		
		for(int i = 0; i < posicionV.size(); i++) {
			if(tablero.getCelda(posicionV.get(i)) == vivo) {
				celdasV++;
			}
		}
		
		EstadoCelda nuevo = muerto;
		if(tablero.getCelda(posicion) == vivo) {
			if(celdasV == 2 || celdasV == 3) {
				nuevo = vivo;
			}
			else {
				nuevo = muerto;
			}
		}
		else {
			if(celdasV == 3) {
				nuevo = vivo;
			}
			else {
				nuevo = muerto;
			}
		}
		
		return nuevo;
	}
}
