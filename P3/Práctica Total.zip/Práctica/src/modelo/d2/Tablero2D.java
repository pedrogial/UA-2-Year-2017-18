package modelo.d2;

import java.util.HashMap;

import modelo.EstadoCelda;
import modelo.Tablero;
import modelo.excepciones.*;

/**
 * Clase Tablero2D heredada de Tablero: Matriz de celdas usadas en el juego de la vida, para dimensiones 2D.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public abstract class Tablero2D  extends Tablero<Coordenada2D>{
	
	/**
	 * Constructor: crea un objeto de clase Tablero2D insertando en cada celda el 
	 * estado MUERTA y guarda las posiciones de la dimension 2D en el HashMap celdas.
	 * 
	 * Instantiates a new tablero 2D.
	 *
	 * @param x the x
	 * @param y the y
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 */
	public Tablero2D(int x, int y) throws ExcepcionArgumentosIncorrectos, ExcepcionCoordenadaIncorrecta{
		super(new Coordenada2D(x, y));
		
		int i, j;
		celdas = new HashMap<Coordenada2D, EstadoCelda>();
		for(i = 0; i < (dimensiones).getX(); i++) {
			for(j = 0; j < (dimensiones).getY(); j++) {
				try {
					celdas.put(new Coordenada2D(i, j), EstadoCelda.MUERTA);
				} 
				catch(ExcepcionCoordenadaIncorrecta e) {
					throw new ExcepcionEjecucion(e);
				}
			}
		}
	}
}