package modelo.d2;

import java.util.ArrayList;

import modelo.EstadoCelda;
import modelo.Imprimible;
import modelo.excepciones.*;


/**
 * Clase TableroCeldasCuadradas heredada de Tablero2D: Matriz de celdas cuadradas vecinas, usadas en el Tablero2D.
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class TableroCeldasCuadradas extends Tablero2D implements Imprimible{
	
	@Override
	public String generaCadena() {
		return toString();
	}
	
	/**
	 * Constructor: llama al constructor madre, el de la clase Tablero2D, ya que lo puede heredar.
	 * Instantiates a new tablero celdas cuadradas.
	 *
	 * @param x the x
	 * @param y the y
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionCoordenadaIncorrecta the excepcion coordenada incorrecta
	 */
	public TableroCeldasCuadradas(int x, int y) throws ExcepcionArgumentosIncorrectos, ExcepcionCoordenadaIncorrecta{
		super(x, y);
	}

	/**
	 * Devuelve un vector de posiciones en orden anti-horario de las celdas vecinas 
	 * a la especificada en el parámetro posición.
	 *
	 * @param posicion the posicion
	 * @throws ExcepcionArgumentosIncorrectos the excepcion argumentos incorrectos
	 * @throws ExcepcionPosicionFueraTablero the excepcion posicion fuera tablero
	 * @throws ExcepcionEjecucion the excepcion ejecucion
	 */
	public ArrayList<Coordenada2D> getPosicionesVecinasCCW(Coordenada2D posicion) throws ExcepcionPosicionFueraTablero, ExcepcionArgumentosIncorrectos, ExcepcionEjecucion{
		ArrayList<Coordenada2D> radiopatio = null;
		radiopatio = new ArrayList<Coordenada2D>();
		
		if(posicion == null) {
			throw new ExcepcionArgumentosIncorrectos();
		}
		
		if(!contiene(posicion)) {
			throw new ExcepcionPosicionFueraTablero(dimensiones, posicion);
		}
		
		int x, y;
		x = ((Coordenada2D)posicion).getX();
		y = ((Coordenada2D)posicion).getY();
		
		try {
			if(contiene(new Coordenada2D(x - 1, y - 1))) {
				radiopatio.add(new Coordenada2D(x - 1, y - 1));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x - 1, y))) {
				radiopatio.add(new Coordenada2D(x - 1, y));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x - 1, y + 1))) {
				radiopatio.add(new Coordenada2D(x - 1, y + 1));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x, y + 1))) {
				radiopatio.add(new Coordenada2D(x, y + 1));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x + 1, y + 1))) {
				radiopatio.add(new Coordenada2D(x + 1, y + 1));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x + 1, y))) {
				radiopatio.add(new Coordenada2D(x + 1, y));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x + 1, y - 1))) {
				radiopatio.add(new Coordenada2D(x + 1, y - 1));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		try {
			if(contiene(new Coordenada2D(x, y - 1))) {
				radiopatio.add(new Coordenada2D(x, y - 1));
			}
		}catch(ExcepcionCoordenadaIncorrecta e) {}
		
		return radiopatio;
	}

	@Override
	public String toString() {
		String s = "";
		s = s + "+";
		
		int x, y;
		x = ((Coordenada2D)dimensiones).getX();
		y = ((Coordenada2D)dimensiones).getY();
		
		try {
			for(int i = 1; i <= x; i++) {
				s = s + "-";
			}
			s = s + "+" + "\n";
			for(int i = 0; i < y; i++) {
				s = s + "|";
				for(int j = 0; j < x; j++) {
					if(celdas.get(new Coordenada2D(j, i)) == EstadoCelda.VIVA) {
						s = s + "*";
					}
					else {
						s = s + " ";
					}
				}
				s = s + "|" + "\n";
			}
			
			s = s + "+";
			for(int i = 1; i <= x; i++) {
				s = s + "-";
			}
			s = s + "+" + "\n";
		}catch(ExcepcionCoordenadaIncorrecta e) { 
			throw new ExcepcionEjecucion(e);
		}
		return s;
	}
}