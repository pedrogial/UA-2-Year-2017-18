package modelo.excepciones;

/**
 * La clase ExcepcionArgumentosIncorrectos
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionArgumentosIncorrectos extends ExcepcionEjecucion{
	
	/**
	 * Instantiates a new excepcion argumentos incorrectos.
	 */
	public ExcepcionArgumentosIncorrectos() {
		super("Error");
	}
}
