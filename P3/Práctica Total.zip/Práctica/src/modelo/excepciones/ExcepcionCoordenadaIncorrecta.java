package modelo.excepciones;

/**
 * La clase ExcepcionCoordenadaIncorrecta
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionCoordenadaIncorrecta extends Exception{
	
	/**
	 * Instantiates a new excepcion coordenada incorrecta.
	 */
	public ExcepcionCoordenadaIncorrecta() {
		
	}
}
