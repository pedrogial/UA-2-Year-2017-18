package modelo.excepciones;

/**
 * La clase ExcepcionEjecucion
 * @author Pedrogial(Pedro Giménez Aldeguer) 15419933C
 * @version 4.0
 */
public class ExcepcionEjecucion extends RuntimeException{
	
	/**
	 * Instantiates a new excepcion ejecucion.
	 *
	 * @param mensaje the mensaje
	 */
	public ExcepcionEjecucion(String mensaje) {
		super(mensaje);
	}
	
	/**
	 * Instantiates a new excepcion ejecucion.
	 *
	 * @param cause the cause
	 */
	public ExcepcionEjecucion(Throwable cause) {
		super(cause);
	}
}
