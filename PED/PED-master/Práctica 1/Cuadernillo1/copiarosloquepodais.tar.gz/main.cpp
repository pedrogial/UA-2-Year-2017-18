#include "tcalendario.h"
int main(){
	TCalendario c;
	TCalendario c2(3, 3, 1903, "jose");
	TCalendario c3(c2);
	cout << c.Dia() << " " << c.Mes() << " " << c.Anyo() << endl;

	if(c2 == c3){
		// const TCalendario *this = &c2;
		// const TCalendario &de = c3;
		cout << "calendarios iguales" << endl;
	}
	if(c2 + 3 == c3){
		// TCalendario + int => TCalendario
	}
	
	TCalendario c1(30, 1, 1900, NULL);
	c1++;
	
	c2 = ++c1;
	c3 = c1++;

	cout << c1;
	
	cout << c2 << c3 << endl;
	
	return 0;
}
