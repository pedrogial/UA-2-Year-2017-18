#include "tcalendario.h"
#include <cstring>
#include <cstdlib>
TCalendario::TCalendario(){
	dia = 1;
	mes = 1;
	anyo = 1900;
	mensaje = NULL;
}

TCalendario::TCalendario(int dia, int mes, int anyo, char *mensaje){
	///  comprobar que la fecha es correcta,
	///  si no es correcta o el año no es >= 1900 inicializarla
	// a 1 del 1 1900
	if(esCorrecta(dia, mes, anyo) == true) {	
		this->dia = dia;
		this->mes = mes;
		this->anyo = anyo;
		if(mensaje != NULL){
			this->mensaje = new char [strlen(mensaje) + 1];
			strcpy(this->mensaje, mensaje);
			// this->mensaje = strdup(mensaje);
		}
		else{
			this->mensaje = NULL;
		}
	}
	else{
		this->dia = 1;
		this->mes = 1;
		this->anyo = 1900;
		this->mensaje = NULL;
	}
}
TCalendario::TCalendario(const TCalendario &c){
	dia = c.dia;
	mes = c.mes;
	anyo = c.anyo;
	if(c.mensaje == NULL){
		mensaje = NULL;
	} 
	else{
		mensaje = new char [strlen(c.mensaje) + 1];
		strcpy(mensaje, c.mensaje);
	}
}
TCalendario::~TCalendario(){
	dia = 1; mes = 1; anyo = 1900;
	if(mensaje != NULL){
		delete [] mensaje;
		mensaje = NULL;
	}
}
int TCalendario::Dia() const{ return dia; }
int TCalendario::Mes() const{ return mes; }
int TCalendario::Anyo() const {return anyo; }

bool TCalendario::esCorrecta(int d, int m, int a){
	bool es = false;
	if(a >= 1900){
		if(m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12){
			if(d >= 1 && d <= 31){
				es = true;
			}
		}
		else{
			if(m == 4 || m == 6 || m == 9 || m == 11){
				if(d >= 1 && d <= 30){
					es = true;
				}
			}
			else{
				if(m == 2){
					if(a % 4 == 0 && a % 100 != 0 || a % 400 == 0){
						if(d >= 1 && d <= 29){
							es = true;
						}
					}
					else{
						if(d >= 1 && d <= 28){
							es = true;
						}
					}
				}
			}
		}
	}
	return es;
}
// el const del metodo modifica el puntero this, para que el puntero
// this sea constante.
//		=> metodo const si no modifico el operando de la izquierda
//		=> parametro constante si no modifico el operando de la derecha
bool TCalendario::operator==(const TCalendario &de) const{
	bool es = false;
	if(dia == de.dia && mes == de.mes && anyo == de.anyo){
		if(mensaje == NULL && de.mensaje == NULL){
			es = true;
		}
		else{
			if(mensaje != NULL && de.mensaje != NULL){
				if(strcmp(de.mensaje, mensaje) == 0){
					es = true;
				}
			}
		}	
	}	
	return es;
}
bool TCalendario::operator!=(const TCalendario &de) const{
	return !(*this == de);
}

// -1 si m1 < m2
// 0 si m1 = m2 
// 1 si m1 > m2
int TCalendario::cmpMensaje(char m1[], char m2[]) const{
	int r = -1;

	if(m1 != NULL && m2 == NULL){
		r = 1;
	}
	else{
		if(m1 == NULL && m2 == NULL){
			r = 0;
		}
		else{
			if(m1 != NULL && m2 != NULL){
				r = strcmp(m1, m2);
			}
		}
	}
	return r;
}
bool TCalendario::operator>(const TCalendario &de) const{
	bool mayor = false;
	if(anyo > de.anyo){
		mayor = true;
	}
	else{
		if(anyo == de.anyo){
			if(mes > de.mes){
				mayor = true;
			}
			else{
				if(mes == de.mes){
					if(dia > de.dia){
						mayor = true;
					}
					else{
						if(cmpMensaje(mensaje, de.mensaje) > 0){
							mayor = true;
						}
					}
				}
			}
		}
	}
	return mayor;
}
bool TCalendario::operator<(const TCalendario &de) const{
	return !(*this == de && *this > de);		
}

TCalendario TCalendario::operator+(int de) const{
	int i;
	TCalendario resultado(*this);
	for(i = 1; i <= de; i++){
		++resultado;
	}
	return resultado;
}

// pre incremento => incrementarlo y devolverlo.
TCalendario &TCalendario::operator++(){
	const int dias [] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	int maxdias;

	dia++;
	maxdias = dias[mes];
	if(mes == 2 && (anyo % 4 == 0 && anyo % 100 != 0 || anyo % 400 == 0)){
		if(dia == 30){
			mes = 3;
			dia = 1;
		}	
	}
	else{
		if(dia == maxdias + 1){
			mes++;
			dia = 1;
			if(mes == 13){
				mes = 1;
				anyo++;
			}
		}
	}
	return *this;
}

TCalendario TCalendario::operator++(int x){
	TCalendario r(*this);
	++(*this);
	return r;
}
	
ostream &operator<<(ostream &os, const TCalendario &c){
	if(c.dia < 10){
		os << '0'; // os << 0;
	}	
	os << c.dia;
	os << "/";
	if(c.mes < 10){
		os << '0';
	}
	os << c.mes << "/";
	if(c.anyo < 10){
		os << "0";
	}
	os << c.anyo;
	os << " ";
	os << '"';
	if(c.mensaje != NULL){
		os << c.mensaje;
	}
	os << '"';

	return os;
}

TCalendario &TCalendario::operator=(const TCalendario &de){
	if(this != &de){
		dia = de.dia;
		mes = de.mes;
		anyo = de.anyo;
		if(mensaje != NULL){
			delete [] mensaje;
			mensaje = NULL;
		}
		if(de.mensaje != NULL){
			mensaje = new char [strlen(de.mensaje) + 1];
			strcpy(mensaje, de.mensaje);
		}
	}
	return *this;
}









