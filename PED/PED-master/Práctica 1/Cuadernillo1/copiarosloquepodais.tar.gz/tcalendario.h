#ifndef _tcalendario
#define _tcalendario
#include <iostream>
using namespace std;
class TCalendario{
	friend ostream &operator<<(ostream &os, const TCalendario &de);
	private:
		int dia, mes, anyo;
		char *mensaje; // cadena de caracteres.
		bool esCorrecta(int d, int m, int a); // *****
		int cmpMensaje(char m1[], char m2[]) const;
	public: 
		TCalendario();
		TCalendario(int dia, int mes, int anyo, char *);
		TCalendario(const TCalendario &c);
		~TCalendario();
		
		int Dia() const;
		int Mes() const;
		int Anyo() const;

		// sobrecargar operador => indicar como funciona un operador con nuestros
		// tipos de datos, le vamos a decir como tiene que comparar dos calendarios
		// 		- como funcion
		//			- aparecen como parametros todos los operandos.
		//			- si no es funcion amiga usaremos los metodos publicos
		// 			para acceder a la parte privada de la clase.
		//		- como metodo de clase
		//			- el operando de la izquierda sera el objeto que invoca el
		//			metodo, no aparece en la lista de parametros =>
		//			- para poder sobrecargar un operador como metodo de clase
		//			el operando de la izquierda tiene que ser de tipo TCalendario
		//			porque this se va a quedar apuntando al operando izquierdo
		// 			y this es de tipo TCalendario *
		bool operator==(const TCalendario &de) const;
		bool operator!=(const TCalendario &de) const;
		bool operator<(const TCalendario &de) const;
		bool operator>(const TCalendario &de) const;

		TCalendario operator+(int de) const;

		TCalendario &operator++();
		TCalendario operator++(int i);
		TCalendario &operator--();
		TCalendario operator--(int i);


		TCalendario &operator=(const TCalendario &de);

};
#endif
