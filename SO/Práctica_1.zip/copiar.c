// PEDRO GIMENEZ ADEGUER
// ANDREA MILAN CAMPILLO

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

//TAMAÑO
#define KTAM 10

int main(int argc, char *argv[]) {
    int f_origen, f_destino, tam;
    char buffer[KTAM];
    int tuberia[2], pid;

    if (argc == 3) {
        //Abres el fichero
        f_origen = open(argv[1], O_RDONLY);

        if (f_origen < 0) {
            printf("Error al abrir %s\n", argv[1]);
        }
        else {
            pipe(tuberia);
            pid = fork();

            if (pid != 0) { // padre
                close(tuberia[0]); // no lee
                
                tam = read(f_origen, buffer, KTAM - 1); // '- 1' porque el último caracter es '\0'
                // Lee cada línea y la mete dentro de la tubería
                while (tam != 0) {
                    write(tuberia[1], buffer, tam);
                    tam = read(f_origen, buffer, KTAM - 1);
                }
          	    close(f_origen);
          	    close(tuberia[1]);
            }
            else { // hijo
          	    close(tuberia[1]); // no escribe
                //Crea el fichero
                f_destino = creat(argv[2], 0777); // Siempre debe crearse en la dirección de memoria '0777'
                
                tam = read(tuberia[0], buffer, KTAM - 1);
                while (tam != 0) {
                    write(f_destino, buffer, tam);
                    buffer[tam] = '\0';  // Final de fichero
                    printf("%s", buffer);
                    tam = read(tuberia[0], buffer, KTAM - 1);
          	    }
          	    close(f_destino);
          	    close(tuberia[0]);
            }
        }
    }	
  return 0;
}


