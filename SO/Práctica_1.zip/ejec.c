// PEDRO GIMENEZ ADEGUER
// ANDREA MILAN CAMPILLO

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

// Funcion vacía
void nada() {}

// Muestra el ls
void ejecuta_ls() {
	int pid;
  	pid = fork();
  	if (pid != 0) {
    	wait(NULL);
  	}
  	else {
    	execlp("ls", "ls", NULL);
  	}
}

// Muestra el árbol de procesos
void ejecuta_pstree() {
  	int pid;
  	pid = fork();
 	if(pid != 0) {
    	wait(NULL);
  	}
  	else {
    	execlp("pstree", "pstree", NULL);
  	}
}

int main(int argc, char *argv[]) {
  	int i, pid, pid_ejec, pidA, pidB, pidX, pidY;
  	int tiempo; // Tiempo de espera (argumento 2)

  	if (argc != 3) {
    	printf("error en argumentos\n");
  	}
  	else {
    	// pasamos la cadena 1 a entero.
    	tiempo = atoi(argv[2]);
    
    	printf("Soy el proceso ejec: mi pid es %d\n", getpid());
    	pid_ejec = getpid();	
    	pid = fork();

    	// Proceso padre
    	if (pid != 0) {
      		wait(NULL); // espera a que A se despierte
      		printf("Soy ejec(%d) y muero\n", getpid());
    	}
    	else {
      		// esto lo ejecuta el nuevo proceso A
      		pidA = getpid();		
      		printf("Soy el proceso A: mi pid es %d. Mi padre %d\n", pidA, getppid());	
      		pid = fork();
      		if (pid != 0) {
	
				// A es el nuevo proceso padre
				// Ejecuta una de estas dos funciones en función del argumento pasado
				//signal(SIGUSR1, nada); // Se prepara para la señal
				signal(SIGUSR2, ejecuta_pstree); // Muestra el árbol de procesos

				// Esto no se ejecuta hasta que todos terminen
				wait(NULL);
				printf("Soy A(%d) y muero\n", getpid());
      		}
     		else {
				// B es el hijo de A
				pidB = getpid();
				printf("Soy el proceso B: mi pid es %d. Mi padre es %d. Mi abuelo es %d\n", pidB, pidA, pid_ejec); 
				for (i = 1; i <= 3; i++) {
		  			pid = fork();
				  		// Rellenamos el pidX y el pidY para cuando Z nazca
				  	if (pid != 0) { // B.
				   		switch(i){
				   			case 1:
			    				pidX = pid;
			      			break;
			    			case 2:
			      				pidY = pid;
			      			break;			
				    	}
					}
					if(pid == 0){					
			    		switch (i) {
			    			case 1:
			      				printf("Soy el proceso X: mi pid es %d. Mi padre es %d. Mi abuelo es %d. Mi bisabuelo es %d\n", getpid(), pidB, pidA, pid_ejec);
			      				signal(SIGUSR1, nada); // se prepara para la señal
				   				signal(SIGUSR2, ejecuta_ls);								
				   				pause();
			      				signal(SIGALRM, nada);
			      				alarm(3);		      
				      			pause(); // Se queda parado hasta que llega una señal
				      			printf("Soy X(%d) y muero\n", getpid());					
				      			break;				
					    	case 2:
					      		printf("Soy el proceso Y: mi pid es %d. Mi padre es %d. Mi abuelo es %d. Mi bisabuelo es %d\n", getpid(), pidB, pidA, pid_ejec);
					   			signal(SIGUSR1, nada); // se prepara para la señal
					   			signal(SIGUSR2, ejecuta_ls);
				      			pause();	      
					      		signal(SIGALRM, nada);
					      		alarm(2);
					      		pause();							
					      		printf("Soy Y(%d) y muero\n", getpid());
					      		break;
					    	case 3:
					      		printf("Soy el proceso Z: mi pid es %d. Mi padre es %d. Mi abuelo es %d. Mis bisabuelo es %d\n", getpid(), pidB, pidA, pid_ejec);

					     		// transcurridos los segundos seleccionados Z se debe despertar
					 			signal(SIGALRM, nada);
				    			alarm(tiempo); // programo el reloj para que me envie la señal SIGALRM transcurrido el tiempo especificado
				      			pause(); // me quedo durmiendo esperando la alarma
				      			

				      			// Manda señales a los procesos
				      			switch (argv[1][0]) {
					      			case 'A':
										printf("Soy el proceso A con pid %d, he recibido la señal.\n", pidA);
										kill(pidA, SIGUSR2);
										kill(pidX, SIGUSR1);
										kill(pidY, SIGUSR1);
									break;
									case 'B':
										printf("Soy el proceso B con pid %d, he recibido la señal.\n", pidB);
										kill(pidB, SIGUSR2);
										kill(pidX, SIGUSR1);
										kill(pidY, SIGUSR1);
									break;
									case 'X':
										printf("Soy el proceso X con pid %d, he recibido la señal.\n", pidX);
										kill(pidX, SIGUSR2);
										kill(pidY, SIGUSR1);
									break;
									case 'Y':
										printf("Soy el proceso Y con pid %d, he recibido la señal.\n", pidY);
										kill(pidX, SIGUSR1);
										kill(pidY, SIGUSR2);
									break;									 
				      			}
					      		signal(SIGALRM, nada);
					      		alarm(1);
					      		pause();			
					   			printf("Soy Z(%d) y muero\n", getpid()); // Como todo se hace desde Z, no funcionará si se ejecuta con parámetro 'Z'
					      	break;
				    	}
				    	break; // los hijos salen del bucle for
			  		}	
				}
				// aqui B tendra que esperar a 3 procesos
				if (i == 4) {
					signal(SIGUSR1, nada); 
					// Se prepara para la señal
	  				signal(SIGUSR2, ejecuta_pstree);
	    			for (i = 1; i <= 3; i++) {
	    				wait(NULL);
	    			}
	    			printf("Soy B(%d) y muero\n", getpid());
	  			}
	  			
      		}		
    	}
  	}
}
