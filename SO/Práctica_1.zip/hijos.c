// PEDRO GIMENEZ ADEGUER
// ANDREA MILAN CAMPILLO

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

int main(int argc, char * argv[]) {
  int x, y, pid, i, j;
  int shmidx, shmidy;

  int *pidx, *pidy; // Al usar punteros los valores son compartidos por todos los procesos
  
  if(argc == 3) {
		x = atoi(argv[1]);
		y = atoi(argv[2]);

		// Reservar memoria como esta en el ejemplo
		shmidx = shmget(IPC_PRIVATE, sizeof(int) * (x + 1), IPC_CREAT | 0666); // 'x + 1' porque también contamos al padre
		shmidy = shmget(IPC_PRIVATE, sizeof(int) * y, IPC_CREAT | 0666);

		// Vinculamos el segmento de memoria compartida como esta en el ejemplo
		pidx = (int *) shmat(shmidx, 0, 0);
		pidy = (int *) shmat(shmidy, 0, 0);

		pidx[0] = getpid(); // hijos (que es el padre, pero se llama así)
		for (i = 1; i <= x; i++) {
		  	pid = fork();
		  	if (pid != 0) {
				wait(NULL); // Paramos al padre (llamado hijos)
				if (i == 1) {
		  		printf("Soy el superpadre (%d): mis hijos finales son:  ", getpid());
		  		for (j = 1; j <= x; j++) {
						printf("%d ", pidx[j]);
		  		}
		  
		  		for (j = 0; j < y; j++) {
						printf("%d ", pidy[j]);
		  		}
		  		printf("\n");
				}
				break;
			}
			else {
				// Hijos
				pidx[i] = getpid();
				printf("Soy el subhijo %d, mis padres son: ", pidx[i]);
				for (j = 0; j < i; j++) {
	  			printf("%d ", pidx[j]);
				}
				printf("\n");
		  }
		}

		// Cuando sale del 'for', la i se incrementa en 1
		if (i == x + 1) {
		  for (j = 1; j <= y; j++) {
				pid = fork();

				if (pid == 0) {
		  			pidy[j - 1] = getpid();
		  			sleep(30);
		 			break;
				}
		  }
		  if (j == y + 1) {
				for (j = 1; j <= y; j++) {
		  		wait(NULL);
				}
		  }
		}
  } 
  return 0;
}
