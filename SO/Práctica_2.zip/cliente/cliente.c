#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#define KTAM 512

int main(int argc, char *argv[]){
	//Variables.
	if(argc == 2) {
	    char buffer[KTAM];
	    int Socket, tam, puerto;

	    // struct para almacenar la informacion sobre la dirección del servidor.
	    struct sockaddr_in struct_servidor;
	    // struct para almacenar la información sobre el host remoto.
	    struct hostent *server;

	    // Se crea un socket para el cliente.
	    Socket = socket(AF_INET, SOCK_STREAM, 0);

	    if (Socket < 0) 
	        perror("Error. No se pudo crear socket");
		else{
			// Para coger el que se pasa como parámetro.
			server = gethostbyname(argv[1]);
			if(server == NULL) {
				perror("Error. El host al que se quiere acceder no existe.");
				exit(1);
			}

			// Inicializa todos los campos del struct a 0.
		    bzero((char *) &struct_servidor, sizeof(struct_servidor));

		    // Se rellena el struct del servidor.
			// para que las conexiones puedan ser o en distintos PC o en el mismo PC.
			struct_servidor.sin_family = AF_INET;
			// el "int puerto" se convierte a formato máquina.
			struct_servidor.sin_port = htons(9999);

			// Se copia la información del server* en la información del servidor.
			// h_addr es la direccion del servidor. (No es necesario)
			bcopy((char *)server->h_addr, (char *)&struct_servidor.sin_addr.s_addr, server->h_length);

			// Se establece conexión entre el cliente y el servidor.
			if (connect(Socket ,(struct sockaddr *) &struct_servidor,sizeof(struct_servidor)) < 0){ 
			    perror("Error. No se pudo conectar al Socket");
			}
			else{
				do{
					//Escritura en la terminal del fichero "Google.html".
					tam = read(Socket, buffer, KTAM -1);
					if(tam > 0){
						buffer[tam] = '\0';
			        	printf("%s",buffer);
					}		    
				}while(tam > 0);
				//Cerramos el Socket.
				close(Socket);

			}
		}
	}	
	else {
		printf("Error, debe haber dos parámetros de entrada. \n");
		printf("Ejecución: ./cliente [IP_servidor] \n");
	}
	
    return 0;
}
