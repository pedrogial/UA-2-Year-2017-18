#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <sys/types.h> 
#include <sys/wait.h>
#define KTAM 256

int main(int argc, char *argv[]){
	char buffer[KTAM];
	pid_t pid;
	socklen_t tam;

	// struct para almacenar la información del servidor.
	struct sockaddr_in struct_servidor;
	// struct para almacenar la información del cliente.
	struct sockaddr_in struct_cliente;
	// Variables para los sockets y el fichero.
   	int Socket, SocketNuevo, fichero;


	// Se crea un socket para el servidor.
	Socket = socket(AF_INET, SOCK_STREAM, 0);

	if (Socket < 0) 
		perror("Error. No se pudo abrir el Socket\n");
	else{

		// Inicializa todos los campos del struct a 0.
		bzero((char *) &struct_servidor, sizeof(struct_servidor));

		// Se rellena el struct del servidor.
		// para que las conexiones puedan ser o en distintos PC o en el mismo PC.
		struct_servidor.sin_family = AF_INET;
		// el "int puerto" se convierte a formato máquina.
		struct_servidor.sin_port = htons(9999);
		// para que se pueda aceptar cualquier dirección.
		struct_servidor.sin_addr.s_addr = INADDR_ANY;

		// Se asocia el puerto con el socket del servidor.
		if(bind(Socket, (struct sockaddr *) &struct_servidor, sizeof(struct_servidor)) < 0){ 
			perror("Error. No se pudo vincular el Socket\n");
		}
		else{
			// Se mira si hay alguna conexión entrante en el puerto.
			listen(Socket, 5);
			// Se crea un hijo para que se pueda ejecutar el comando leido.
			//(Igual que el ejercicio de ficheros de la práctica 1)
			pid = fork(); 
			if(pid == 0){  
				tam = sizeof(struct_cliente);
				SocketNuevo = accept(Socket, (struct sockaddr *) &struct_cliente, &tam);
				if(SocketNuevo < 0){ 
					perror("Error. Al aceptar la conexion del cliente");
				}
				else{
					//Lo abrimos.
					fichero = open("Google.html", O_RDONLY);
					if(fichero < 0){
						perror("Error. Al abrir el fichero\n");
						perror("'Google.html' no encontrado\n");
					}					
					else{
						do{
							tam = read(fichero, buffer, KTAM - 1);			
							if(tam > 0){
								write(SocketNuevo, buffer, tam);
							}
						}while(tam > 0);
					}
					//Se ciera el socket y el fichero.	
				}
			}
			else{
				//Mueren
				wait(NULL);
				printf("Leido correctamente 'Google.html'\n");
			}
		}
	}
	close(SocketNuevo);
	close(Socket);
	close(fichero);

	return 0; 
}
